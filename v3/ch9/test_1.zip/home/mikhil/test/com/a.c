int sqr(num)
{
    return num*num;
}
