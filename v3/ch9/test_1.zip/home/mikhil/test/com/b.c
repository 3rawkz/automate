main()
{
    sqr(10);
}
